# Duplicador Remoto de Entradas DGE

Plugin para duplicar entradas desde un WordPress origen hacia un WordPress destino mediante REST API autenticada con Application Password.

## Version entregada

1.0.8

## Autor

Por Equipo del Portal DGE Gob. de Mendoza

https://www.mendoza.edu.ar/

## Cambios principales

- Sincroniza imagen destacada.
- Sincroniza medios embebidos en el contenido.
- Reemplaza URLs locales del origen por URLs del destino.
- Reemplaza IDs de imagen en bloques Gutenberg y galerias clasicas `[gallery ids="..."]`.
- Meta box en editor con estado de sincronizacion y boton de sync AJAX.
- Columna "Sincronizado" en listado de entradas con iconos de estado.
- Logs en directorio no publico con rotacion automatica.
- Advertencia de seguridad para conexiones sin HTTPS.
- Mantiene logs y pruebas de conexion REST.
